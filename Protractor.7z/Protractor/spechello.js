describe('Protractor Demo App', function() {
    it('should have a title', function() {
      browser.get('https://angularjs.org/');  
      element(by.model('yourName')).sendKeys('Rachel');
      var text = element(by.xpath("//div[@app-run='hello.html']//h1")).getText();  
      expect(text.getText()).toEqual('Hello Rachel!');   
    });
  });