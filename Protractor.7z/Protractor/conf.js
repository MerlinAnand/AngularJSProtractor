exports.config = {
    framework: 'jasmine',
    seleniumAddress: 'http://localhost:4444/wd/hub',
    specs: ['Multiple.js'],
    multiCapabilities: [{
      browserName: 'firefox'
    },{
      browserName: 'chrome'
    }]
  };