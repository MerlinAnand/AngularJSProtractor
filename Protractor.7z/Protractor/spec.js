  describe('Super Calculator test', function() {
        //global variables
        var firstNumber = element(by.model('first'));
        var secondNumber = element(by.model('second'));
        var goButton = element(by.id('gobutton'));
        var result = element(by.xpath("//h2[@class='ng-binding']"));

        //before each function will be invoked before every it block
        beforeEach(function(){
          browser.get('http://juliemr.github.io/protractor-demo/');
        });

        //TC1
         it('Should have a title', function() {
          expect(browser.getTitle()).toEqual('Super Calculator');         
         });

        //TC2
        it('Should add values', function() {
          firstNumber.sendKeys(2);
          secondNumber.sendKeys(5);
          goButton.click();
          expect(result.getText()).toEqual('7');
        });         


        //TC3
        it('Should add values', function() {
          firstNumber.sendKeys(6);
          secondNumber.sendKeys(8);
          goButton.click();
          expect(result.getText()).toEqual('14');
        }); 
        
        //TC4
        it('should read the value from an input', function(){
          firstNumber.sendKeys(6);
          expect(firstNumber.getAttribute('value')).toEqual('6');
        });        
  });