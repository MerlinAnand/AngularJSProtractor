describe('multiple scenarios',function(){
    var firstNumber = element(by.model('first'));
    var secondNumber = element(by.model('second'));
    var goButton = element(by.id('gobutton'));
    var result = element(by.xpath("//h2[@class='ng-binding']"));
    var history= element.all(by.repeater('result in memory'));

     //before each function will be invoked before every it block
     beforeEach(function(){
        browser.get('http://juliemr.github.io/protractor-demo/');
      });

      function add(a,b){
        firstNumber.sendKeys(a);
        secondNumber.sendKeys(b);
        goButton.click();
      }

    it('check the history',function(){
        add(1,2);
        add(5,7);
        add(3,9);                
        expect(history.count()).toEqual('3');
    });     
});